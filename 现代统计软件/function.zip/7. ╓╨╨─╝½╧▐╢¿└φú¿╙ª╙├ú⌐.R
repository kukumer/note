# 中心极限定理（函数应用）
# 函数：limite.central
# 举例
#
# Yuehan Yang. 2014/9/24 yyh@cufe.edu.cn

# 二项分布: b(10,0,1)
op <- par(mfrow=c(2,2))
limite.central(rbinom, distpar=c(10 ,0.1), m=1, s=0.9)
par(op)

# 泊松分布：pios(1)
op <- par(mfrow=c(2,2))
limite.central(rpois, distpar=1, m=1, s=1, n=c(3, 10, 30 ,50))
par(op)

# 均匀分布: unif(0,1)
op <- par(mfrow=c(2,2))
limite.central()
par(op)

# 指数分布：exp(1)
op <- par(mfrow=c(2,2))
limite.central(rexp, distpar=1, m=1, s=1)

