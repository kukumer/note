# 控制结构应用
# 展示中心极限定理
# 练习
#
# Yuehan Yang. 2014/9/9 yyh@cufe.edu.cn

# 1. 分割图形
par(mfrow=c(2,2))
# 2. 选择数据信息
# 样本数量1，3，10，30
# 每个样本有一千个来自均匀分布的随机数
runif
# 3. 中心极限定理计算公式
Sn - \mu*n/sqrt(\var *n)
# 4. 统计描述
hist; density; 正态分布密度曲线

