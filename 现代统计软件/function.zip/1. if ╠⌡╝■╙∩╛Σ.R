# 编程之控制结构
#
# 即便没有用过各类语言，是不是也听说过 for 循环，if 语句等常用的命令？
# 和其他的编程语言一样，R 也有一些与 C 语言类似的控制结构
# 本小节介绍几个著名的命令
#
# Yuehan Yang. 2014/9/9 yyh@cufe.edu.cn

# 条件语句
# if 常用的两种方式：if-else/ifelse
# 简单例子
#
# 1. if-else 结构
# if (cond) statement
# if (cond) statement1 else staement2
#
# e.g.
x <- 5
if (x >= 0) sqrt(x) else NA

# 2. ifelse 结构
# 它是 if-else 结构的紧凑化版本
# ifelse(cond, statement1, statement2)
ifelse(x >= 0,sqrt(x),NA)
#
# 备注（可忽略）：
# 但前者在 x 为矩阵时，前者有可能报错，例如
X <- matrix(1:4,4)
if (X>= 0) sqrt(X) else NA
ifelse( X >= 0, sqrt(X),NA)
Y <- matrix(-3:0,4)
if (Y >= 0) sqrt(Y) else NA
ifelse( Y >= 0, sqrt(Y),NA)
#
#
# 总结规律
# 常用模板
# if ( CONDITION ) 
# { 
#   STATEMENT1 
#   STATEMENT2 
#   ETC 
# } 
#
# STATEMENT1是你想要执行的指令
#
# if ( CONDITION ) 
# { 
#   STATEMENT1 
#   STATEMENT2 
#   ETC }
# else { 
#   STATEMENT3 
#   STATEMENT4
#   ETC 
# } 
# 当只有一个 STATEMENT 时，可以不加 {}
