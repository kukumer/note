# 中心极限定理 简版
#
# Yuehan Yang. 2014/9/24 yyh@cufe.edu.cn

limite.central <- function (r=runif, distpar=c(0,1), m=.5,
                            s=1/sqrt(12),
                            n=c(1,3,10,30), N=1000) {
  for (i in n) {
    if (length(distpar)==2){
      x <- matrix(r(i*N, distpar[1],distpar[2]),nc=i)
    }
    else {
      x <- matrix(r(i*N, distpar), nc=i)
    }
    x <- (apply(x, 1, sum) - i*m )/(sqrt(i)*s)
    hist(x,col='light blue',probability=T,main=paste("n=",i),
         ylim=c(0,max(.4, density(x)$y)))
    lines(density(x), col='red', lwd=3)
    curve(dnorm(x), col='blue', lwd=3, lty=3, add=T)
    if( N>100 ) {
      rug(sample(x,100))
    }
    else {
      rug(x)
    }
  }
}
