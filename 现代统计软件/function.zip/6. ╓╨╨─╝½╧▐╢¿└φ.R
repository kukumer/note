# 中心极限定理
# 定理简要介绍： X_1,...,X_n 为独立随机变量，当 n 充分大时
# 其和近似服从正态分布
#
# 下面的函数给出了从图形上考察一个由已知分布产生的
# 容量为 n 的样本在标准化后趋于标准正态分布的近似程度
# 函数：limite.central
#
# Yuehan Yang. 2014/9/24 yyh@cufe.edu.cn

limite.central <- function (r=runif, distpar=c(0,1), m=.5,
                            s=1/sqrt(12),
                            n=c(1,3,10,30), N=1000) {
  for (i in n) {
    if (length(distpar)==2){
      # if 条件语句，想一想这是什么意思
      x <- matrix(r(i*N, distpar[1],distpar[2]),nc=i)
      # r 缺省为均匀分布，缺省最小值、最大值由 distpar 给定
    }
    else {
      x <- matrix(r(i*N, distpar), nc=i)
    }
    x <- (apply(x, 1, sum) - i*m )/(sqrt(i)*s) # 中心极限定理
    hist(x,col='light blue',probability=T,main=paste("n=",i),
         ylim=c(0,max(.4, density(x)$y)))
    # 关于 x 的直方图
    lines(density(x), col='red', lwd=3)
    # 计算 x 的核密度估计值
    curve(dnorm(x), col='blue', lwd=3, lty=3, add=T)
    # 计算 x 处标准正态分布的密度函数值
    if( N>100 ) {
      rug(sample(x,100))
    }
    else {
      rug(x)
    }
  }
}
