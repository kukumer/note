# 编程之控制结构
# 循环结构
# 主要有三个表现形式：
# 1. for 循环
# 2. while 循环
# 3. repeat （不太常用）
# 简单区分：
# 终止条件已知，则用 for 循环； 不知道循环次数使用 while/repeat 
#
# Yuehan Yang. 2014/9/9 yyh@cufe.edu.cn

# for 循环
# e.g.1
for (i in 1:5) print (1:i)
# i 从 1 到 5, 分别被输出 1 到 i 
#
# e.g.2
for (i in 1:10) print ( "Hello")
# "Hello" 被输出 10 次
#
# while 循环
#
# e.g.1
i=1
while ( i <= 5){
  print(1:i)
  i=i+1
}
# 与 for 循环 e.g.1 类似
#
# e.g.2
i <- 10
while (i > 0) {print ("Hello"); i <- i-1}
# 与 for 循环 e.g.2 类似
# 需要确保 while 的条件语句能够改变，即在某个时候不再为真——否则循环将永无休止
# e.g. i <- i-1
# repeat 循环
i=1
repeat {
  print (1:i)
  i=i+1
  if (i >5) break
}
# 如上所述：
# repeat 循环通过 break 跳出循环
# while 循环：while (条件) {命令函数}
# for 循环：for (变量 in 向量) {命令函数}



# 通用模板
# while 循环
#　while (CONDITION)
# { STATEMENT1
#   STATEMENT2
#   ETC
# }
# 这里 {} 是你的循环的限制，如果不加 {}, while 循环将只考虑 STATEMENT1
#
# for 循环
# for (VAR in VECTOR)
# { STATEMENT1
#   STATEMENT2
#   ETC
# }
