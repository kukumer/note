# 控制结构应用
# 展示中心极限定理
#
#
# Yuehan Yang. 2014/9/9 yyh@cufe.edu.cn

# 分割图形
par(mfrow=c(2,2))
# 
for(n in c(1,3,10,30))
  # for 循环
  # n 取 1,3,10,30
{
  N = 1000
  # N 赋值
  x <- matrix(runif(n*N, 0,1), ncol = n)
  # 均匀分布随机数构成的矩阵
  ave = 0.5
  # ave 表示该分布均值,0.5
  v = 1/12 
  # v 为方差
  x <- (apply(x, 1, sum) - n*ave )/sqrt(n*v)
  # 求和标准化
  hist(x,col='light blue',probability=T,main=paste("n=",n),
       ylim=c(0,max(.4, density(x)$y)))
  # hist 直方图
  # col 填充柱条的颜色
  # probability 是否概率值
  # main 题目格式
  # ylim y 轴范围
  lines(density(x), col='red', lwd=3)
  # density 密度估计
  curve(dnorm(x), col='blue', lwd=3, lty=3, add=T)
  # 正态分布的密度函数
  if( N>100 ) {
    rug(sample(x,100))
  } else {
    rug(x)
  }
  # rug 在绘制图形中添加点
} 

